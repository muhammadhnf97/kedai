import React from 'react'

const Footer = () => {
  return (
    <footer className='w-full text-center text-sm itelic bg-black py-2 text-white'>Copyright by Muhammad Hanif 2023</footer>
  )
}

export default Footer