export const searchBarangBy = [{
    label: 'Masukan keywords ...',
    key: 'keyword',
    type: 'text'
},{
    label: 'Kategori',
    key: 'idKategori',
    type: 'select',
    table: 'barang'
},]

export const searchBy = [{
    label: 'Masukan Keywords ...',
    key: 'keyword',
    type: 'text'
}]  